### 2.0.0 - 06/13/2015

- Rebuilt theme from ground-up to be compatible with Sequence.js 2

### 1.3.0 - 03/11/2013

- Updated to work with Sequence.js 0.0.9
- Added height: 100% and width: 100% to the top level UL to allow for detection of mouseenter/mouseleave
- The pagination will now move up a little when hovered over rather than fade in
- Added transition-property to animated elements
